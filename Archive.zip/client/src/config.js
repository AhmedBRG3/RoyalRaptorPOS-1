// Centralized frontend config (no env)
export const API_URL = 'http://localhost:5050';


