
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'omartest',
  applicationName: 'rrp',
  appUid: 'NVPSZz1DNCVyTstjpv',
  orgUid: '8904bf2f-0ae9-4252-a5d5-5b2c5b03be32',
  deploymentUid: '7facceb2-c40a-452f-9944-566a79dd409e',
  serviceName: 'RoyalRaptorPOS',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'RoyalRaptorPOS-dev-api', timeout: 30 };

try {
  const userHandler = require('./src/app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}